import $ from 'jquery';
import { Console } from './modules/console.ts';

$(function () {
    Console.initialize();
});

export { Console };
